{
    "4'd15": lambda x: f"{x}'b{'1' * x}",
    "[5:0]": lambda x: f"[{x + 1}:0]",
    "[3:0]": lambda x: f"[{x - 1}:0]",
    "[5:4]": lambda x: f"[{x + 1}:{x}]",
}
