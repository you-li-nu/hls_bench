http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt
